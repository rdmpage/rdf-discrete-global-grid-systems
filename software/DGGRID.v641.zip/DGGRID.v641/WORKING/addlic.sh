#!/bin/bash

f=$1
echo adding $f..
cp licenseHdr.txt tmpFile
cat $f >> tmpFile
mv tmpFile $f
